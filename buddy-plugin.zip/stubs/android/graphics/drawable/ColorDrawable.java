package android.graphics.drawable;
public class ColorDrawable extends Drawable { public ColorDrawable(int c){} }
