package android.graphics;
public class Paint { public static final int ANTI_ALIAS_FLAG=1; public enum Align{LEFT,CENTER,RIGHT} public enum Style{FILL,STROKE,FILL_AND_STROKE}
 public Paint(int f){} public void setColor(int c){} public Shader setShader(Shader s){return s;} public void setStyle(Style s){} public void setTextAlign(Align a){}
 public void setTextSize(float s){} public void setFakeBoldText(boolean b){} public void setStrokeWidth(float w){} public float measureText(String s){return 0;}
 public float ascent(){return 0;} public float descent(){return 0;} }
