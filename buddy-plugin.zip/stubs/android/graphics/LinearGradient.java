package android.graphics;
public class LinearGradient extends Shader { public LinearGradient(float a,float b,float c,float d,int c0,int c1,Shader.TileMode t){} }
