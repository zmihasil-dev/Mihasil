package android.graphics;
public class Rect { public int width(){return 0;} }
