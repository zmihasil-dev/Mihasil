package android.graphics;
public class Path { public enum Direction {CW,CCW} public void reset(){} public void moveTo(float x,float y){} public void lineTo(float x,float y){} public void close(){} public void addOval(RectF r,Direction d){} }
