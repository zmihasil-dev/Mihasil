package android.media;
public class AudioTrack { public static final int MODE_STATIC=0;
 public AudioTrack(int a,int b,int c,int d,int e,int f){} public int write(short[] a,int b,int c){return 0;}
 public void play(){} public void stop(){} public void release(){} public int setPlaybackHeadPosition(int p){return 0;} }
