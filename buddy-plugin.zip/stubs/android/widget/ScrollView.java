package android.widget;
public class ScrollView extends android.view.ViewGroup { public ScrollView(android.content.Context c){super(c);} public void addView(android.view.View v){} }
