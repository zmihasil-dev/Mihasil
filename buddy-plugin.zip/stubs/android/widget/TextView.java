package android.widget;
public class TextView extends android.view.View { public TextView(android.content.Context c){super(c);} public CharSequence getText(){return null;} public void setText(CharSequence s){}
 public void setTextColor(int c){} public void setTextSize(float s){} public float getTextSize(){return 0;} public void setGravity(int g){}
 public android.text.Layout getLayout(){return null;} public int getExtendedPaddingTop(){return 0;} public int getCompoundPaddingLeft(){return 0;} public int getPaddingRight(){return 0;}
 public android.graphics.drawable.Drawable[] getCompoundDrawables(){return null;} }
