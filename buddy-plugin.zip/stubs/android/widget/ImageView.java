package android.widget;
public class ImageView extends android.view.View { public enum ScaleType{CENTER_CROP} public ImageView(android.content.Context c){super(c);} public void setImageBitmap(android.graphics.Bitmap b){} public void setScaleType(ScaleType s){} }
