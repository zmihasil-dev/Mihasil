package android.widget;
public class EditText extends TextView { public EditText(android.content.Context c){super(c);} public void setHint(CharSequence s){} public void setHintTextColor(int c){} public void setSingleLine(boolean b){}
 public android.text.Editable getText(){return null;} }
