package android.app;
public class Activity extends android.content.Context { public android.view.Window getWindow(){return null;} public int checkSelfPermission(String p){return 0;} public void requestPermissions(String[] p,int c){} }
