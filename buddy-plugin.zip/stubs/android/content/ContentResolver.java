package android.content;
public abstract class ContentResolver { public android.database.Cursor query(android.net.Uri u,String[] p,String s,String[] a,String o){return null;} public java.io.InputStream openInputStream(android.net.Uri u) throws java.io.FileNotFoundException {return null;} }
