package cat.narezany.margyt.plugin;
public abstract class MargyPlugin {
  public final PluginContext margyt(){return null;}
  public void onStart(android.content.Context c){}
  public void onStop(){}
  public void onActivityResumed(android.app.Activity a){}
  public void onActivityPaused(android.app.Activity a){}
}
