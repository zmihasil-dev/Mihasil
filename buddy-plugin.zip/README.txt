Сюрприз для margyT (.mtp). Сборка: ./build.sh
