package buddy.margyt;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

/** Звуки, синтезируются кодом (файлов в плагине нет). */
final class BuddySfx {

    static final int JUMP = 0, POP = 1, THUD = 2, FANFARE = 3, YAWN = 4;
    private static final int RATE = 22050;

    private final AudioTrack[] tracks = new AudioTrack[5];
    private volatile boolean released;

    BuddySfx() {
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    for (int i = 0; i < tracks.length && !released; i++) {
                        AudioTrack t = build(make(i));
                        if (released) {
                            free(t);
                        } else {
                            tracks[i] = t;
                        }
                    }
                } catch (Throwable ignored) {
                }
            }
        });
        th.setDaemon(true);
        th.start();
    }

    void play(int id) {
        try {
            AudioTrack t = tracks[id];
            if (t == null) return;
            t.stop();
            t.setPlaybackHeadPosition(0);
            t.play();
        } catch (Throwable ignored) {
        }
    }

    void release() {
        released = true;
        for (int i = 0; i < tracks.length; i++) {
            free(tracks[i]);
            tracks[i] = null;
        }
    }

    private static void free(AudioTrack t) {
        try {
            if (t != null) {
                t.stop();
                t.release();
            }
        } catch (Throwable ignored) {
        }
    }

    private static AudioTrack build(short[] pcm) {
        AudioTrack t = new AudioTrack(AudioManager.STREAM_MUSIC, RATE,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                pcm.length * 2, AudioTrack.MODE_STATIC);
        t.write(pcm, 0, pcm.length);
        return t;
    }

    private static short[] norm(float[] x, float level) {
        float peak = 0.0001f;
        for (int i = 0; i < x.length; i++) peak = Math.max(peak, Math.abs(x[i]));
        short[] o = new short[x.length];
        float k = level * 32767f / peak;
        for (int i = 0; i < x.length; i++) o[i] = (short) (x[i] * k);
        return o;
    }

    private static short[] make(int id) {
        switch (id) {
            case JUMP:
                return sweep(0.22f, 300f, 760f, 6f, 0.55f);
            case POP:
                return sweep(0.09f, 900f, 1500f, 18f, 0.4f);
            case THUD:
                return sweep(0.16f, 170f, 60f, 14f, 0.7f);
            case YAWN:
                return sweep(0.7f, 420f, 190f, 2.2f, 0.45f);
            default:
                return fanfare();
        }
    }

    /** Тон с плавным сдвигом частоты и затуханием. */
    private static short[] sweep(float dur, float f0, float f1, float decay, float level) {
        int n = (int) (RATE * dur);
        float[] x = new float[n];
        double ph = 0;
        for (int i = 0; i < n; i++) {
            float t = i / (float) RATE;
            float u = t / dur;
            float f = f0 + (f1 - f0) * u;
            ph += 2.0 * Math.PI * f / RATE;
            float env = (float) Math.exp(-t * decay) * Math.min(1f, i / 90f);
            x[i] = ((float) Math.sin(ph) + 0.3f * (float) Math.sin(2 * ph)) * env;
        }
        return norm(x, level);
    }

    /** Весёлая восходящая мелодия. */
    private static short[] fanfare() {
        float[] notes = {523f, 659f, 784f, 1047f, 784f, 1047f, 1319f};
        float step = 0.11f;
        int n = (int) (RATE * (step * notes.length + 0.4f));
        float[] x = new float[n];
        for (int k = 0; k < notes.length; k++) {
            int s = (int) (RATE * step * k);
            for (int i = s; i < n; i++) {
                float t = (i - s) / (float) RATE;
                float env = (float) Math.exp(-t * 7.0);
                if (env < 0.01f) break;
                float sq = Math.sin(2 * Math.PI * notes[k] * t) > 0 ? 1f : -1f;
                x[i] += (sq * 0.3f + (float) Math.sin(2 * Math.PI * notes[k] * t) * 0.7f) * env;
            }
        }
        return norm(x, 0.55f);
    }
}
