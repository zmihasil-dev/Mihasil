package buddy.margyt;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;

import java.util.ArrayList;
import java.util.Random;

/** Прозрачный слой поверх приложения. Касания проходят в приложение, кроме самого персонажа. */
final class BuddyView extends View {

    interface Logger {
        void log(String s);
    }

    private static final int IDLE = 0, WALK = 1, WAVE = 2, HOP = 3, SIT = 4, SLEEP = 5, DANCE = 6,
            CARRIED = 7, FALL = 8, LOOK = 9;

    private static final String[] PHRASES = {
            "Привет!", "Скроллим?", "Я тут просто гуляю", "Йоу", "Не щекочи!", "Ещё одно видео...",
            "Ты красавчик", "Хихи", "Куда летим?", "Лайк не забудь :3", "Ой!", "Мяу? Ой, не то",
            "Я за тобой слежу (шучу)", "Хочешь потанцую?", "Эй, я тут!"
    };

    private static final class Bit {
        float x, y, vx, vy, rot, vr, w;
        int color;
        long born;
        int life;
    }

    private final Logger logger;
    private final float dp;
    private final int slop;
    private final BuddySfx sfx;
    private final Random rnd = new Random();

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF r = new RectF();
    private final ArrayList<Bit> bits = new ArrayList<Bit>();

    private Activity activity;
    private boolean running, drawFailed;
    private long last;

    // положение: x — центр, y — стопы
    private float px = -1f, py, vx, vy;
    private float ground;
    private int state = IDLE;
    private long stateStart, stateEnd, lastTouch, squashUntil, bubbleUntil, lastBlink;
    private int dir = 1;
    private float walkPhase;
    private String bubble = "";

    // касания
    private boolean down, dragging;
    private float downX, downY, offX, offY, lastMx, lastMy;
    private long lastMt;
    private float fvx, fvy;
    private int tapCount;
    private long firstTap;

    private final Runnable stepper = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            step();
            postOnAnimation(this);
        }
    };

    BuddyView(Context context, Logger logger) {
        super(context);
        this.logger = logger;
        this.dp = context.getResources().getDisplayMetrics().density;
        this.slop = ViewConfiguration.get(context).getScaledTouchSlop();
        this.sfx = new BuddySfx();
        setWillNotDraw(false);
        line.setStyle(Paint.Style.STROKE);
        text.setFakeBoldText(true);
    }

    void setActivity(Activity a) {
        activity = a;
    }

    void clearActivity(Activity a) {
        if (activity == a) activity = null;
    }

    void destroy() {
        running = false;
        removeCallbacks(stepper);
        sfx.release();
        bits.clear();
    }

    private float scale() {
        return 0.95f * dp;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        ground = h - 86f * dp;
        if (px < 0f) {
            px = w * 0.3f;
            py = ground;
            enter(IDLE, 800);
        }
        px = clamp(px, 30f * dp, w - 30f * dp);
        if (state != CARRIED && state != FALL) py = ground;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = true;
        last = SystemClock.uptimeMillis();
        lastTouch = last;
        removeCallbacks(stepper);
        postOnAnimation(stepper);
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        removeCallbacks(stepper);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------ поведение

    private void enter(int s, long durMs) {
        state = s;
        stateStart = SystemClock.uptimeMillis();
        stateEnd = stateStart + durMs;
    }

    private void say(String s, long ms) {
        bubble = s;
        bubbleUntil = SystemClock.uptimeMillis() + ms;
        sfx.play(BuddySfx.POP);
    }

    private void pickNext(long now) {
        if (now - lastTouch > 30000L && state != SLEEP) {
            enter(SLEEP, 1000000L);
            sfx.play(BuddySfx.YAWN);
            say("Zzz...", 1500);
            return;
        }
        int k = rnd.nextInt(100);
        if (k < 55) {
            dir = rnd.nextBoolean() ? 1 : -1;
            if (px < getWidth() * 0.2f) dir = 1;
            if (px > getWidth() * 0.8f) dir = -1;
            enter(WALK, 1500 + rnd.nextInt(3000));
        } else if (k < 66) {
            enter(WAVE, 1500);
            say("Привет!", 1400);
        } else if (k < 78) {
            enter(HOP, 600);
            sfx.play(BuddySfx.JUMP);
            vy = -9f * dp;
            py = ground - 1f;
        } else if (k < 88) {
            enter(SIT, 2500 + rnd.nextInt(3000));
        } else {
            enter(LOOK, 1800);
        }
        if (rnd.nextInt(5) == 0) say(PHRASES[rnd.nextInt(PHRASES.length)], 2200);
    }

    private void step() {
        try {
            long now = SystemClock.uptimeMillis();
            float dt = Math.min(50f, (float) (now - last)) / 16.67f;
            last = now;
            float W = getWidth();
            if (px < 0f) {
                invalidate();
                return;
            }
            switch (state) {
                case WALK:
                    px += dir * 1.6f * dp * dt;
                    walkPhase += 0.22f * dt;
                    if (px < 34f * dp) {
                        px = 34f * dp;
                        dir = 1;
                    } else if (px > W - 34f * dp) {
                        px = W - 34f * dp;
                        dir = -1;
                    }
                    if (now >= stateEnd) enter(IDLE, 500 + rnd.nextInt(1500));
                    break;
                case HOP:
                    py += vy * dt;
                    vy += 0.7f * dp * dt;
                    if (py >= ground) {
                        py = ground;
                        squashUntil = now + 120;
                    }
                    if (now >= stateEnd && py >= ground) enter(IDLE, 600);
                    break;
                case DANCE:
                    py = ground - Math.abs((float) Math.sin((now - stateStart) / 130.0)) * 10f * dp;
                    if (rnd.nextInt(3) == 0) spawnBit(px, py - 70f * scale() * 1.0f / 1f, now);
                    if (now >= stateEnd) {
                        py = ground;
                        enter(IDLE, 500);
                        say("Ух, запыхался", 1800);
                    }
                    break;
                case FALL:
                    vy += 0.75f * dp * dt;
                    px += vx * dt;
                    py += vy * dt;
                    if (px < 30f * dp) {
                        px = 30f * dp;
                        vx = -vx * 0.6f;
                    } else if (px > W - 30f * dp) {
                        px = W - 30f * dp;
                        vx = -vx * 0.6f;
                    }
                    if (py < 40f * dp) {
                        py = 40f * dp;
                        vy = Math.abs(vy) * 0.4f;
                    }
                    if (py >= ground) {
                        py = ground;
                        if (vy > 6f * dp) {
                            vy = -vy * 0.38f;
                            vx *= 0.7f;
                            squashUntil = now + 160;
                            sfx.play(BuddySfx.THUD);
                        } else {
                            vy = 0f;
                            vx = 0f;
                            enter(IDLE, 900);
                            if (rnd.nextInt(3) == 0) say("Ой-ой", 1600);
                        }
                    }
                    break;
                case CARRIED:
                    walkPhase += 0.25f * dt;
                    break;
                case SLEEP:
                    break;
                default:
                    if (now >= stateEnd) pickNext(now);
                    break;
            }
            for (int i = bits.size() - 1; i >= 0; i--) {
                Bit b = bits.get(i);
                if (now - b.born > b.life) bits.remove(i);
            }
            invalidate();
        } catch (Throwable t) {
            safeLog("buddy: step failed: " + t);
        }
    }

    private void spawnBit(float x, float y, long now) {
        if (bits.size() > 80) return;
        int[] pal = {0xFFFFD34D, 0xFFFF5A7A, 0xFF4AD8FF, 0xFF7CFF6A, 0xFFB07CFF, 0xFFFFFFFF};
        Bit b = new Bit();
        b.x = x + (rnd.nextFloat() - 0.5f) * 40f * dp;
        b.y = y;
        b.vx = (rnd.nextFloat() - 0.5f) * 5f * dp;
        b.vy = (-1f - rnd.nextFloat() * 4f) * dp;
        b.rot = rnd.nextFloat() * 360f;
        b.vr = (rnd.nextFloat() - 0.5f) * 18f;
        b.w = (3f + rnd.nextFloat() * 4f) * dp;
        b.color = pal[rnd.nextInt(pal.length)];
        b.born = now;
        b.life = 900 + rnd.nextInt(900);
        bits.add(b);
    }

    // ------------------------------------------------------------ касания

    private boolean hitMe(float x, float y) {
        if (px < 0f) return false;
        float s = scale();
        return x > px - 34f * s && x < px + 34f * s && y > py - 112f * s && y < py + 6f * s;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        try {
            int a = e.getActionMasked();
            float x = e.getX(), y = e.getY();
            long now = SystemClock.uptimeMillis();
            if (a == MotionEvent.ACTION_DOWN) {
                down = hitMe(x, y);
                if (!down) return false;
                dragging = false;
                downX = x;
                downY = y;
                offX = px - x;
                offY = py - y;
                lastMx = x;
                lastMy = y;
                lastMt = now;
                fvx = 0f;
                fvy = 0f;
                ViewParent p = getParent();
                if (p != null) p.requestDisallowInterceptTouchEvent(true);
                return true;
            }
            if (!down) return false;
            if (a == MotionEvent.ACTION_MOVE) {
                if (!dragging) {
                    float dx = x - downX, dy = y - downY;
                    if (Math.sqrt(dx * dx + dy * dy) > slop * 1.5f) {
                        dragging = true;
                        enter(CARRIED, 1000000L);
                        lastTouch = now;
                        sfx.play(BuddySfx.JUMP);
                    }
                }
                if (dragging) {
                    long dtm = Math.max(1L, now - lastMt);
                    fvx = fvx * 0.6f + 0.4f * (x - lastMx) / dtm * 16.67f;
                    fvy = fvy * 0.6f + 0.4f * (y - lastMy) / dtm * 16.67f;
                    lastMx = x;
                    lastMy = y;
                    lastMt = now;
                    px = clamp(x + offX, 30f * dp, getWidth() - 30f * dp);
                    py = clamp(y + offY, 60f * dp, getHeight());
                }
                return true;
            }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                down = false;
                lastTouch = now;
                if (dragging) {
                    dragging = false;
                    vx = clamp(fvx, -22f * dp, 22f * dp);
                    vy = clamp(fvy, -22f * dp, 22f * dp);
                    enter(FALL, 1000000L);
                } else if (a == MotionEvent.ACTION_UP) {
                    onTap(now);
                }
                return true;
            }
            return true;
        } catch (Throwable t) {
            safeLog("buddy: touch failed: " + t);
            return false;
        }
    }

    private void onTap(long now) {
        if (now - firstTap > 1600) {
            firstTap = now;
            tapCount = 0;
        }
        tapCount++;
        if (tapCount >= 5) {
            tapCount = 0;
            enter(DANCE, 4500);
            sfx.play(BuddySfx.FANFARE);
            say("ТАНЦЫ!", 3000);
            for (int i = 0; i < 40; i++) spawnBit(px, py - 80f * scale(), now);
            return;
        }
        if (state == SLEEP) {
            say("А? Что?", 1600);
        } else if (rnd.nextInt(2) == 0) {
            say(PHRASES[rnd.nextInt(PHRASES.length)], 2200);
        }
        enter(HOP, 600);
        sfx.play(BuddySfx.JUMP);
        vy = -9.5f * dp;
        py = ground - 1f;
    }

    // ------------------------------------------------------------ рисование

    @Override
    protected void onDraw(Canvas c) {
        try {
            if (px < 0f) return;
            long now = SystemClock.uptimeMillis();
            drawShadow(c);
            drawBuddy(c, now);
            drawBubble(c, now);
            drawBits(c, now);
        } catch (Throwable t) {
            if (!drawFailed) {
                drawFailed = true;
                safeLog("buddy: draw failed: " + t);
            }
        }
    }

    private void drawShadow(Canvas c) {
        float h = Math.max(0f, Math.min(1f, (ground - py) / (160f * dp)));
        float sw = 24f * scale() * (1f - 0.5f * h);
        fill.setShader(null);
        fill.setColor(((int) (70 * (1f - h)) << 24));
        r.set(px - sw, ground - 4f * scale(), px + sw, ground + 4f * scale());
        c.drawOval(r, fill);
    }

    private void box(Canvas c, float l, float t, float rr, float b, float rad, int color) {
        fill.setColor(color);
        r.set(l, t, rr, b);
        c.drawRoundRect(r, rad, rad, fill);
    }

    private void limb(Canvas c, float pivX, float pivY, float angle, float l, float t, float rr, float b,
                      float rad, int color, int tipColor, float tipFrom) {
        c.save();
        c.translate(pivX, pivY);
        c.rotate(angle);
        box(c, l, t, rr, b, rad, color);
        if (tipColor != 0) box(c, l, tipFrom, rr, b, rad, tipColor);
        c.restore();
    }

    private void drawBuddy(Canvas c, long now) {
        float s = scale();
        int YEL = 0xFFF6DC3C, YEL2 = 0xFFE8C92A, SKIN = 0xFFC68B59, SKIN2 = 0xFFB87B4B;
        boolean walking = state == WALK;
        boolean carried = state == CARRIED || (state == FALL && Math.abs(vy) > 2f * dp);
        boolean sitting = state == SIT || state == SLEEP;
        float sq = now < squashUntil ? 0.88f : 1f;

        float legA = 0f, legB = 0f, armA = 0f, armB = 0f, tilt = 0f, bob = 0f, headTilt = 0f;
        float eyeShift = dir * 1.4f;
        if (walking) {
            float sw = (float) Math.sin(walkPhase);
            legA = sw * 28f;
            legB = -sw * 28f;
            armA = -sw * 30f;
            armB = sw * 30f;
            bob = -Math.abs(sw) * 2.5f;
            tilt = dir * 3f;
        } else if (state == WAVE) {
            armB = 150f + (float) Math.sin((now - stateStart) / 90.0) * 22f;
            armA = 6f;
        } else if (state == HOP) {
            armA = 55f;
            armB = -55f;
            legA = 12f;
            legB = -12f;
        } else if (state == DANCE) {
            float t = (now - stateStart) / 130f;
            armA = 140f + (float) Math.sin(t * 2f) * 30f;
            armB = -140f - (float) Math.sin(t * 2f + 1.5f) * 30f;
            legA = (float) Math.sin(t * 2f) * 24f;
            legB = -legA;
            tilt = (float) Math.sin(t) * 9f;
            headTilt = (float) Math.sin(t * 2f) * 6f;
        } else if (carried) {
            float sw = (float) Math.sin(walkPhase);
            armA = 160f + sw * 12f;
            armB = -160f - sw * 12f;
            legA = sw * 18f;
            legB = -sw * 18f;
        } else if (state == LOOK) {
            eyeShift = (float) Math.sin((now - stateStart) / 260.0) * 3f;
            headTilt = eyeShift * 2.5f;
        } else if (sitting) {
            armA = 8f;
            armB = -8f;
            bob = 0f;
        } else {
            armA = 4f + (float) Math.sin(now / 500.0) * 2f;
            armB = -armA;
            bob = (float) Math.sin(now / 600.0) * 0.8f;
        }

        c.save();
        c.translate(px, py);
        c.scale(s, s * sq);
        c.rotate(tilt);
        c.translate(0f, bob);
        if (sitting) c.translate(0f, 14f);

        // ноги
        if (sitting) {
            box(c, -16f, -22f, -3f, -8f, 3f, YEL2);
            box(c, 3f, -22f, 16f, -8f, 3f, YEL2);
            box(c, -17f, -10f, -2f, 0f, 3f, 0xFFF4F4F4);
            box(c, 2f, -10f, 17f, 0f, 3f, 0xFFF4F4F4);
        } else {
            limb(c, -7f, -30f, legA, -5.5f, 0f, 5.5f, 30f, 2.5f, YEL2, 0xFFF4F4F4, 25f);
            limb(c, 7f, -30f, legB, -5.5f, 0f, 5.5f, 30f, 2.5f, YEL2, 0xFFF4F4F4, 25f);
        }
        // торс
        box(c, -15f, -62f, 15f, -29f, 3f, YEL);
        box(c, -15f, -34f, 15f, -29f, 2f, YEL2);
        // смайлик на футболке
        line.setStrokeWidth(1.6f);
        line.setColor(0xFF111111);
        c.drawLine(-4.5f, -54f, -4.5f, -51f, line);
        c.drawLine(4.5f, -54f, 4.5f, -51f, line);
        r.set(-6f, -52f, 6f, -43f);
        c.drawArc(r, 20f, 140f, false, line);
        // руки
        limb(c, -19.5f, -60f, armA, -4.5f, -3f, 4.5f, 27f, 2.5f, SKIN, YEL, 9f);
        limb(c, 19.5f, -60f, armB, -4.5f, -3f, 4.5f, 27f, 2.5f, SKIN, YEL, 9f);
        // голова
        c.save();
        c.translate(0f, -62f);
        c.rotate(headTilt);
        c.translate(0f, 62f);
        box(c, -14f, -93f, 14f, -61f, 5f, SKIN);
        // наушники
        fill.setColor(0xFF2A2A2A);
        c.drawCircle(-15f, -77f, 8f, fill);
        c.drawCircle(15f, -77f, 8f, fill);
        fill.setColor(0xFFFFB02E);
        c.drawCircle(-15f, -77f, 6.5f, fill);
        c.drawCircle(15f, -77f, 6.5f, fill);
        fill.setColor(0xFFE8421C);
        c.drawCircle(-15f, -77f, 3.2f, fill);
        c.drawCircle(15f, -77f, 3.2f, fill);
        // волосы: шипы
        path.reset();
        path.moveTo(-15f, -88f);
        path.lineTo(-22f, -104f);
        path.lineTo(-10f, -97f);
        path.lineTo(-12f, -113f);
        path.lineTo(-2f, -100f);
        path.lineTo(3f, -117f);
        path.lineTo(8f, -100f);
        path.lineTo(18f, -110f);
        path.lineTo(14f, -95f);
        path.lineTo(24f, -98f);
        path.lineTo(15f, -86f);
        path.close();
        fill.setColor(0xFFF8E84A);
        c.drawPath(path, fill);
        // чёлка
        path.reset();
        path.moveTo(-15f, -90f);
        path.lineTo(15f, -90f);
        path.lineTo(16f, -78f);
        path.lineTo(10f, -83f);
        path.lineTo(5f, -76f);
        path.lineTo(0f, -84f);
        path.lineTo(-6f, -77f);
        path.lineTo(-10f, -84f);
        path.lineTo(-16f, -77f);
        path.close();
        fill.setColor(0xFFDDBF84);
        c.drawPath(path, fill);
        // глаза
        boolean blink = (now / 100L) % 40L == 0L || state == SLEEP;
        for (int i = -1; i <= 1; i += 2) {
            float ex = i * 6.2f + eyeShift * 0.5f, ey = -74.5f;
            if (blink) {
                line.setStrokeWidth(1.6f);
                line.setColor(0xFF111111);
                c.drawLine(ex - 4f, ey, ex + 4f, ey, line);
            } else {
                fill.setColor(0xFFFFFFFF);
                r.set(ex - 4.8f, ey - 5.2f, ex + 4.8f, ey + 5.2f);
                c.drawOval(r, fill);
                fill.setColor(0xFF111111);
                c.drawCircle(ex + eyeShift * 0.4f, ey + 0.4f, 3.6f, fill);
                fill.setColor(0xFFFFFFFF);
                c.drawCircle(ex + eyeShift * 0.4f + 1.2f, ey - 1.2f, 1.3f, fill);
                c.drawCircle(ex + eyeShift * 0.4f - 1.0f, ey + 1.6f, 0.7f, fill);
            }
        }
        // мордочка :3 и язык
        line.setStrokeWidth(1.2f);
        line.setColor(0xFF2A1A10);
        r.set(-3.4f, -70f, 0f, -66f);
        c.drawArc(r, 0f, 180f, false, line);
        r.set(0f, -70f, 3.4f, -66f);
        c.drawArc(r, 0f, 180f, false, line);
        if (state != SLEEP) {
            fill.setColor(0xFFD2405A);
            r.set(-1.7f, -67f, 1.7f, -62.5f);
            c.drawRoundRect(r, 1.7f, 1.7f, fill);
        }
        c.restore();
        c.restore();

        if (state == SLEEP) drawZzz(c, now);
    }

    private void drawZzz(Canvas c, long now) {
        float s = scale();
        for (int i = 0; i < 3; i++) {
            float t = ((now / 1200f) + i / 3f) % 1f;
            float x = px + 22f * s + t * 18f * s;
            float y = py - 100f * s - t * 40f * s;
            text.setTextAlign(Paint.Align.CENTER);
            text.setTextSize((9f + 7f * t) * dp);
            text.setColor(((int) (255 * (1f - t)) << 24) | 0xFFFFFF);
            c.drawText("Z", x, y, text);
        }
    }

    private void drawBubble(Canvas c, long now) {
        if (now >= bubbleUntil || bubble.length() == 0) return;
        float s = scale();
        long left = bubbleUntil - now;
        float a = left < 300 ? left / 300f : 1f;
        text.setTextAlign(Paint.Align.CENTER);
        text.setTextSize(13f * dp);
        float tw = text.measureText(bubble);
        float bw = tw + 22f * dp, bh = 28f * dp;
        float cx = clamp(px, bw / 2f + 6f * dp, getWidth() - bw / 2f - 6f * dp);
        float top = py - 130f * s - bh - (state == SIT || state == SLEEP ? -14f * s : 0f);
        r.set(cx - bw / 2f, top, cx + bw / 2f, top + bh);
        fill.setShader(null);
        fill.setColor(((int) (240 * a) << 24) | 0xFFFFFF);
        c.drawRoundRect(r, 12f * dp, 12f * dp, fill);
        // хвостик
        path.reset();
        path.moveTo(px - 5f * dp, top + bh - 1f);
        path.lineTo(px + 5f * dp, top + bh - 1f);
        path.lineTo(px, top + bh + 7f * dp);
        path.close();
        c.drawPath(path, fill);
        text.setColor(((int) (255 * a) << 24) | 0x222222);
        c.drawText(bubble, cx, top + bh / 2f + 4.5f * dp, text);
    }

    private void drawBits(Canvas c, long now) {
        for (int i = 0; i < bits.size(); i++) {
            Bit b = bits.get(i);
            long age = now - b.born;
            b.x += b.vx;
            b.y += b.vy;
            b.vy += 0.16f * dp;
            b.rot += b.vr;
            float k = 1f - (float) age / b.life;
            c.save();
            c.translate(b.x, b.y);
            c.rotate(b.rot);
            fill.setColor(((int) (255 * Math.max(0f, k)) << 24) | (b.color & 0xFFFFFF));
            c.drawRect(-b.w / 2f, -b.w / 4f, b.w / 2f, b.w / 4f, fill);
            c.restore();
        }
    }

    private void safeLog(String s) {
        try {
            logger.log(s);
        } catch (Throwable ignored) {
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
